﻿namespace CompProj2UI
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.panel1 = new System.Windows.Forms.Panel();
            this.pictureBox8 = new System.Windows.Forms.PictureBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.am_23 = new System.Windows.Forms.Label();
            this.am_22 = new System.Windows.Forms.Label();
            this.am_21 = new System.Windows.Forms.Label();
            this.am_20 = new System.Windows.Forms.Label();
            this.am_19 = new System.Windows.Forms.Label();
            this.am_18 = new System.Windows.Forms.Label();
            this.am_17 = new System.Windows.Forms.Label();
            this.am_16 = new System.Windows.Forms.Label();
            this.am_15 = new System.Windows.Forms.Label();
            this.am_14 = new System.Windows.Forms.Label();
            this.am_13 = new System.Windows.Forms.Label();
            this.am_24 = new System.Windows.Forms.Label();
            this.am_11 = new System.Windows.Forms.Label();
            this.am_10 = new System.Windows.Forms.Label();
            this.am_9 = new System.Windows.Forms.Label();
            this.am_8 = new System.Windows.Forms.Label();
            this.am_7 = new System.Windows.Forms.Label();
            this.am_6 = new System.Windows.Forms.Label();
            this.am_5 = new System.Windows.Forms.Label();
            this.am_4 = new System.Windows.Forms.Label();
            this.am_3 = new System.Windows.Forms.Label();
            this.am_2 = new System.Windows.Forms.Label();
            this.am_1 = new System.Windows.Forms.Label();
            this.am_12 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.button1 = new System.Windows.Forms.Button();
            this.delete_activity = new System.Windows.Forms.Button();
            this.activity_label = new System.Windows.Forms.Label();
            this.new_activity_button = new System.Windows.Forms.Button();
            this.activity_list = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.label19 = new System.Windows.Forms.Label();
            this.mailSubject = new System.Windows.Forms.RichTextBox();
            this.send_mail = new System.Windows.Forms.Button();
            this.add = new System.Windows.Forms.Button();
            this.label_content = new System.Windows.Forms.Label();
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.content_textbox = new System.Windows.Forms.RichTextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.clock = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel5 = new System.Windows.Forms.Panel();
            this.pictureBox13 = new System.Windows.Forms.PictureBox();
            this.pictureBox12 = new System.Windows.Forms.PictureBox();
            this.pictureBox11 = new System.Windows.Forms.PictureBox();
            this.show_details = new System.Windows.Forms.Button();
            this.pictureBox10 = new System.Windows.Forms.PictureBox();
            this.pictureBox9 = new System.Windows.Forms.PictureBox();
            this.news_title = new System.Windows.Forms.RichTextBox();
            this.published_at = new System.Windows.Forms.Label();
            this.SourceLabel = new System.Windows.Forms.Label();
            this.news_details = new System.Windows.Forms.RichTextBox();
            this.news_pic = new System.Windows.Forms.PictureBox();
            this.pictureBox14 = new System.Windows.Forms.PictureBox();
            this.linkedin = new System.Windows.Forms.PictureBox();
            this.twitter = new System.Windows.Forms.PictureBox();
            this.facebook = new System.Windows.Forms.PictureBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.button2 = new System.Windows.Forms.Button();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.panel6 = new System.Windows.Forms.Panel();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.combo_contacts = new System.Windows.Forms.ComboBox();
            this.combo_joining_contacts = new System.Windows.Forms.ComboBox();
            this.panel7 = new System.Windows.Forms.Panel();
            this.SubjectName = new System.Windows.Forms.TextBox();
            this.Subject = new System.Windows.Forms.Label();
            this.retrieve = new System.Windows.Forms.Button();
            this.Send = new System.Windows.Forms.Button();
            this.label18 = new System.Windows.Forms.Label();
            this.coeditor_mail = new System.Windows.Forms.TextBox();
            this.Coeditor = new System.Windows.Forms.Button();
            this.remove_mail = new System.Windows.Forms.Label();
            this.add_button = new System.Windows.Forms.Button();
            this.remove_button = new System.Windows.Forms.Button();
            this.remove_email = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.Name = new System.Windows.Forms.Label();
            this.surname_text = new System.Windows.Forms.TextBox();
            this.email_text = new System.Windows.Forms.TextBox();
            this.number_text = new System.Windows.Forms.TextBox();
            this.name_text = new System.Windows.Forms.TextBox();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).BeginInit();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox13)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.news_pic)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox14)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.linkedin)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.twitter)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.facebook)).BeginInit();
            this.panel6.SuspendLayout();
            this.panel7.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.pictureBox8);
            this.panel1.Controls.Add(this.label9);
            this.panel1.Controls.Add(this.label8);
            this.panel1.Controls.Add(this.am_23);
            this.panel1.Controls.Add(this.am_22);
            this.panel1.Controls.Add(this.am_21);
            this.panel1.Controls.Add(this.am_20);
            this.panel1.Controls.Add(this.am_19);
            this.panel1.Controls.Add(this.am_18);
            this.panel1.Controls.Add(this.am_17);
            this.panel1.Controls.Add(this.am_16);
            this.panel1.Controls.Add(this.am_15);
            this.panel1.Controls.Add(this.am_14);
            this.panel1.Controls.Add(this.am_13);
            this.panel1.Controls.Add(this.am_24);
            this.panel1.Controls.Add(this.am_11);
            this.panel1.Controls.Add(this.am_10);
            this.panel1.Controls.Add(this.am_9);
            this.panel1.Controls.Add(this.am_8);
            this.panel1.Controls.Add(this.am_7);
            this.panel1.Controls.Add(this.am_6);
            this.panel1.Controls.Add(this.am_5);
            this.panel1.Controls.Add(this.am_4);
            this.panel1.Controls.Add(this.am_3);
            this.panel1.Controls.Add(this.am_2);
            this.panel1.Controls.Add(this.am_1);
            this.panel1.Controls.Add(this.am_12);
            this.panel1.Location = new System.Drawing.Point(65, 34);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(415, 120);
            this.panel1.TabIndex = 7;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.Panel1_Paint);
            // 
            // pictureBox8
            // 
            this.pictureBox8.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox8.Image")));
            this.pictureBox8.Location = new System.Drawing.Point(397, 0);
            this.pictureBox8.Name = "pictureBox8";
            this.pictureBox8.Size = new System.Drawing.Size(18, 19);
            this.pictureBox8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox8.TabIndex = 56;
            this.pictureBox8.TabStop = false;
            this.pictureBox8.Click += new System.EventHandler(this.PictureBox8_Click);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(70, 56);
            this.label9.Name = "label9";
            this.label9.Padding = new System.Windows.Forms.Padding(2);
            this.label9.Size = new System.Drawing.Size(27, 17);
            this.label9.TabIndex = 55;
            this.label9.Text = "PM";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(70, 21);
            this.label8.Name = "label8";
            this.label8.Padding = new System.Windows.Forms.Padding(2);
            this.label8.Size = new System.Drawing.Size(27, 17);
            this.label8.TabIndex = 54;
            this.label8.Text = "AM";
            // 
            // am_23
            // 
            this.am_23.AutoSize = true;
            this.am_23.Location = new System.Drawing.Point(304, 56);
            this.am_23.Name = "am_23";
            this.am_23.Padding = new System.Windows.Forms.Padding(2);
            this.am_23.Size = new System.Drawing.Size(23, 17);
            this.am_23.TabIndex = 53;
            this.am_23.Text = "11";
            this.am_23.Click += new System.EventHandler(this.new_activity);
            // 
            // am_22
            // 
            this.am_22.AutoSize = true;
            this.am_22.Location = new System.Drawing.Point(279, 56);
            this.am_22.Name = "am_22";
            this.am_22.Padding = new System.Windows.Forms.Padding(2);
            this.am_22.Size = new System.Drawing.Size(23, 17);
            this.am_22.TabIndex = 52;
            this.am_22.Text = "10";
            this.am_22.Click += new System.EventHandler(this.new_activity);
            // 
            // am_21
            // 
            this.am_21.AutoSize = true;
            this.am_21.Location = new System.Drawing.Point(259, 56);
            this.am_21.Name = "am_21";
            this.am_21.Padding = new System.Windows.Forms.Padding(2);
            this.am_21.Size = new System.Drawing.Size(17, 17);
            this.am_21.TabIndex = 51;
            this.am_21.Text = "9";
            this.am_21.Click += new System.EventHandler(this.new_activity);
            // 
            // am_20
            // 
            this.am_20.AutoSize = true;
            this.am_20.Location = new System.Drawing.Point(239, 56);
            this.am_20.Name = "am_20";
            this.am_20.Padding = new System.Windows.Forms.Padding(2);
            this.am_20.Size = new System.Drawing.Size(17, 17);
            this.am_20.TabIndex = 50;
            this.am_20.Text = "8";
            this.am_20.Click += new System.EventHandler(this.new_activity);
            // 
            // am_19
            // 
            this.am_19.AutoSize = true;
            this.am_19.Location = new System.Drawing.Point(219, 56);
            this.am_19.Name = "am_19";
            this.am_19.Padding = new System.Windows.Forms.Padding(2);
            this.am_19.Size = new System.Drawing.Size(17, 17);
            this.am_19.TabIndex = 49;
            this.am_19.Text = "7";
            this.am_19.Click += new System.EventHandler(this.new_activity);
            // 
            // am_18
            // 
            this.am_18.AutoSize = true;
            this.am_18.Location = new System.Drawing.Point(199, 56);
            this.am_18.Name = "am_18";
            this.am_18.Padding = new System.Windows.Forms.Padding(2);
            this.am_18.Size = new System.Drawing.Size(17, 17);
            this.am_18.TabIndex = 48;
            this.am_18.Text = "6";
            this.am_18.Click += new System.EventHandler(this.new_activity);
            // 
            // am_17
            // 
            this.am_17.AutoSize = true;
            this.am_17.Location = new System.Drawing.Point(179, 56);
            this.am_17.Name = "am_17";
            this.am_17.Padding = new System.Windows.Forms.Padding(2);
            this.am_17.Size = new System.Drawing.Size(17, 17);
            this.am_17.TabIndex = 47;
            this.am_17.Text = "5";
            this.am_17.Click += new System.EventHandler(this.new_activity);
            // 
            // am_16
            // 
            this.am_16.AutoSize = true;
            this.am_16.Location = new System.Drawing.Point(159, 56);
            this.am_16.Name = "am_16";
            this.am_16.Padding = new System.Windows.Forms.Padding(2);
            this.am_16.Size = new System.Drawing.Size(17, 17);
            this.am_16.TabIndex = 46;
            this.am_16.Text = "4";
            this.am_16.Click += new System.EventHandler(this.new_activity);
            // 
            // am_15
            // 
            this.am_15.AutoSize = true;
            this.am_15.Location = new System.Drawing.Point(139, 56);
            this.am_15.Name = "am_15";
            this.am_15.Padding = new System.Windows.Forms.Padding(2);
            this.am_15.Size = new System.Drawing.Size(17, 17);
            this.am_15.TabIndex = 45;
            this.am_15.Text = "3";
            this.am_15.Click += new System.EventHandler(this.new_activity);
            // 
            // am_14
            // 
            this.am_14.AutoSize = true;
            this.am_14.Location = new System.Drawing.Point(119, 56);
            this.am_14.Name = "am_14";
            this.am_14.Padding = new System.Windows.Forms.Padding(2);
            this.am_14.Size = new System.Drawing.Size(17, 17);
            this.am_14.TabIndex = 44;
            this.am_14.Text = "2";
            this.am_14.Click += new System.EventHandler(this.new_activity);
            // 
            // am_13
            // 
            this.am_13.AutoSize = true;
            this.am_13.Location = new System.Drawing.Point(99, 56);
            this.am_13.Name = "am_13";
            this.am_13.Padding = new System.Windows.Forms.Padding(2);
            this.am_13.Size = new System.Drawing.Size(17, 17);
            this.am_13.TabIndex = 43;
            this.am_13.Text = "1";
            this.am_13.Click += new System.EventHandler(this.new_activity);
            // 
            // am_24
            // 
            this.am_24.AutoSize = true;
            this.am_24.Location = new System.Drawing.Point(329, 56);
            this.am_24.Name = "am_24";
            this.am_24.Padding = new System.Windows.Forms.Padding(2);
            this.am_24.Size = new System.Drawing.Size(23, 17);
            this.am_24.TabIndex = 42;
            this.am_24.Text = "12";
            this.am_24.Click += new System.EventHandler(this.new_activity);
            // 
            // am_11
            // 
            this.am_11.AutoSize = true;
            this.am_11.Location = new System.Drawing.Point(304, 21);
            this.am_11.Name = "am_11";
            this.am_11.Padding = new System.Windows.Forms.Padding(2);
            this.am_11.Size = new System.Drawing.Size(23, 17);
            this.am_11.TabIndex = 41;
            this.am_11.Text = "11";
            this.am_11.Click += new System.EventHandler(this.new_activity);
            // 
            // am_10
            // 
            this.am_10.AutoSize = true;
            this.am_10.Location = new System.Drawing.Point(279, 21);
            this.am_10.Name = "am_10";
            this.am_10.Padding = new System.Windows.Forms.Padding(2);
            this.am_10.Size = new System.Drawing.Size(23, 17);
            this.am_10.TabIndex = 40;
            this.am_10.Text = "10";
            this.am_10.Click += new System.EventHandler(this.new_activity);
            // 
            // am_9
            // 
            this.am_9.AutoSize = true;
            this.am_9.Location = new System.Drawing.Point(259, 21);
            this.am_9.Name = "am_9";
            this.am_9.Padding = new System.Windows.Forms.Padding(2);
            this.am_9.Size = new System.Drawing.Size(17, 17);
            this.am_9.TabIndex = 39;
            this.am_9.Text = "9";
            this.am_9.Click += new System.EventHandler(this.new_activity);
            // 
            // am_8
            // 
            this.am_8.AutoSize = true;
            this.am_8.Location = new System.Drawing.Point(239, 21);
            this.am_8.Name = "am_8";
            this.am_8.Padding = new System.Windows.Forms.Padding(2);
            this.am_8.Size = new System.Drawing.Size(17, 17);
            this.am_8.TabIndex = 38;
            this.am_8.Text = "8";
            this.am_8.Click += new System.EventHandler(this.new_activity);
            // 
            // am_7
            // 
            this.am_7.AutoSize = true;
            this.am_7.Location = new System.Drawing.Point(219, 21);
            this.am_7.Name = "am_7";
            this.am_7.Padding = new System.Windows.Forms.Padding(2);
            this.am_7.Size = new System.Drawing.Size(17, 17);
            this.am_7.TabIndex = 37;
            this.am_7.Text = "7";
            this.am_7.Click += new System.EventHandler(this.new_activity);
            // 
            // am_6
            // 
            this.am_6.AutoSize = true;
            this.am_6.Location = new System.Drawing.Point(199, 21);
            this.am_6.Name = "am_6";
            this.am_6.Padding = new System.Windows.Forms.Padding(2);
            this.am_6.Size = new System.Drawing.Size(17, 17);
            this.am_6.TabIndex = 36;
            this.am_6.Text = "6";
            this.am_6.Click += new System.EventHandler(this.new_activity);
            // 
            // am_5
            // 
            this.am_5.AutoSize = true;
            this.am_5.Location = new System.Drawing.Point(179, 21);
            this.am_5.Name = "am_5";
            this.am_5.Padding = new System.Windows.Forms.Padding(2);
            this.am_5.Size = new System.Drawing.Size(17, 17);
            this.am_5.TabIndex = 35;
            this.am_5.Text = "5";
            this.am_5.Click += new System.EventHandler(this.new_activity);
            // 
            // am_4
            // 
            this.am_4.AutoSize = true;
            this.am_4.Location = new System.Drawing.Point(159, 21);
            this.am_4.Name = "am_4";
            this.am_4.Padding = new System.Windows.Forms.Padding(2);
            this.am_4.Size = new System.Drawing.Size(17, 17);
            this.am_4.TabIndex = 34;
            this.am_4.Text = "4";
            this.am_4.Click += new System.EventHandler(this.new_activity);
            // 
            // am_3
            // 
            this.am_3.AutoSize = true;
            this.am_3.Location = new System.Drawing.Point(139, 21);
            this.am_3.Name = "am_3";
            this.am_3.Padding = new System.Windows.Forms.Padding(2);
            this.am_3.Size = new System.Drawing.Size(17, 17);
            this.am_3.TabIndex = 33;
            this.am_3.Text = "3";
            this.am_3.Click += new System.EventHandler(this.new_activity);
            // 
            // am_2
            // 
            this.am_2.AutoSize = true;
            this.am_2.Location = new System.Drawing.Point(119, 21);
            this.am_2.Name = "am_2";
            this.am_2.Padding = new System.Windows.Forms.Padding(2);
            this.am_2.Size = new System.Drawing.Size(17, 17);
            this.am_2.TabIndex = 32;
            this.am_2.Text = "2";
            this.am_2.Click += new System.EventHandler(this.new_activity);
            // 
            // am_1
            // 
            this.am_1.AutoSize = true;
            this.am_1.Location = new System.Drawing.Point(99, 21);
            this.am_1.Name = "am_1";
            this.am_1.Padding = new System.Windows.Forms.Padding(2);
            this.am_1.Size = new System.Drawing.Size(17, 17);
            this.am_1.TabIndex = 31;
            this.am_1.Text = "1";
            this.am_1.Click += new System.EventHandler(this.new_activity);
            // 
            // am_12
            // 
            this.am_12.AutoSize = true;
            this.am_12.Location = new System.Drawing.Point(329, 21);
            this.am_12.Name = "am_12";
            this.am_12.Padding = new System.Windows.Forms.Padding(2);
            this.am_12.Size = new System.Drawing.Size(23, 17);
            this.am_12.TabIndex = 30;
            this.am_12.Text = "12";
            this.am_12.Click += new System.EventHandler(this.new_activity);
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.button1);
            this.panel2.Controls.Add(this.delete_activity);
            this.panel2.Controls.Add(this.activity_label);
            this.panel2.Controls.Add(this.new_activity_button);
            this.panel2.Controls.Add(this.activity_list);
            this.panel2.Location = new System.Drawing.Point(65, 151);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(228, 205);
            this.panel2.TabIndex = 16;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(154, 108);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(50, 49);
            this.button1.TabIndex = 68;
            this.button1.Text = "Share Activity";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.Share_activity_Click);
            // 
            // delete_activity
            // 
            this.delete_activity.Location = new System.Drawing.Point(154, 58);
            this.delete_activity.Name = "delete_activity";
            this.delete_activity.Size = new System.Drawing.Size(50, 44);
            this.delete_activity.TabIndex = 67;
            this.delete_activity.Text = "Delete Activity";
            this.delete_activity.UseVisualStyleBackColor = true;
            this.delete_activity.Click += new System.EventHandler(this.Delete_activity_Click);
            // 
            // activity_label
            // 
            this.activity_label.AutoSize = true;
            this.activity_label.Location = new System.Drawing.Point(39, 63);
            this.activity_label.Name = "activity_label";
            this.activity_label.Size = new System.Drawing.Size(58, 13);
            this.activity_label.TabIndex = 64;
            this.activity_label.Text = "No Activity";
            // 
            // new_activity_button
            // 
            this.new_activity_button.Location = new System.Drawing.Point(154, 9);
            this.new_activity_button.Name = "new_activity_button";
            this.new_activity_button.Size = new System.Drawing.Size(50, 43);
            this.new_activity_button.TabIndex = 63;
            this.new_activity_button.Text = "New Activity";
            this.new_activity_button.UseVisualStyleBackColor = true;
            this.new_activity_button.Click += new System.EventHandler(this.New_activity_button_Click);
            // 
            // activity_list
            // 
            this.activity_list.AutoSize = true;
            this.activity_list.Location = new System.Drawing.Point(25, 39);
            this.activity_list.Name = "activity_list";
            this.activity_list.Size = new System.Drawing.Size(49, 13);
            this.activity_list.TabIndex = 62;
            this.activity_list.Text = "Activities";
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.label19);
            this.panel3.Controls.Add(this.mailSubject);
            this.panel3.Controls.Add(this.send_mail);
            this.panel3.Controls.Add(this.add);
            this.panel3.Controls.Add(this.label_content);
            this.panel3.Controls.Add(this.richTextBox1);
            this.panel3.Controls.Add(this.content_textbox);
            this.panel3.Location = new System.Drawing.Point(287, 153);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(193, 203);
            this.panel3.TabIndex = 17;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(14, 7);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(43, 13);
            this.label19.TabIndex = 70;
            this.label19.Text = "Subject";
            // 
            // mailSubject
            // 
            this.mailSubject.Location = new System.Drawing.Point(13, 25);
            this.mailSubject.Name = "mailSubject";
            this.mailSubject.Size = new System.Drawing.Size(161, 35);
            this.mailSubject.TabIndex = 69;
            this.mailSubject.Text = "";
            // 
            // send_mail
            // 
            this.send_mail.Location = new System.Drawing.Point(122, 170);
            this.send_mail.Name = "send_mail";
            this.send_mail.Size = new System.Drawing.Size(52, 25);
            this.send_mail.TabIndex = 4;
            this.send_mail.Text = "OK";
            this.send_mail.UseVisualStyleBackColor = true;
            this.send_mail.Click += new System.EventHandler(this.Send_mail_Click);
            // 
            // add
            // 
            this.add.Location = new System.Drawing.Point(133, 117);
            this.add.Name = "add";
            this.add.Size = new System.Drawing.Size(41, 31);
            this.add.TabIndex = 68;
            this.add.Text = "Add";
            this.add.UseVisualStyleBackColor = true;
            this.add.Click += new System.EventHandler(this.Add_Click);
            // 
            // label_content
            // 
            this.label_content.AutoSize = true;
            this.label_content.Location = new System.Drawing.Point(14, 61);
            this.label_content.Name = "label_content";
            this.label_content.Size = new System.Drawing.Size(47, 13);
            this.label_content.TabIndex = 3;
            this.label_content.Text = "Content:";
            // 
            // richTextBox1
            // 
            this.richTextBox1.Location = new System.Drawing.Point(14, 7);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.Size = new System.Drawing.Size(160, 67);
            this.richTextBox1.TabIndex = 67;
            this.richTextBox1.Text = "";
            // 
            // content_textbox
            // 
            this.content_textbox.Location = new System.Drawing.Point(12, 80);
            this.content_textbox.Name = "content_textbox";
            this.content_textbox.Size = new System.Drawing.Size(162, 84);
            this.content_textbox.TabIndex = 2;
            this.content_textbox.Text = "";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.label1.Location = new System.Drawing.Point(138, 11);
            this.label1.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label1.Name = "label1";
            this.label1.Padding = new System.Windows.Forms.Padding(7);
            this.label1.Size = new System.Drawing.Size(42, 27);
            this.label1.TabIndex = 16;
            this.label1.Text = "Mon";
            this.label1.Click += new System.EventHandler(this.Label1_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.label2.Location = new System.Drawing.Point(220, 77);
            this.label2.Name = "label2";
            this.label2.Padding = new System.Windows.Forms.Padding(7);
            this.label2.Size = new System.Drawing.Size(40, 27);
            this.label2.TabIndex = 17;
            this.label2.Text = "Tue";
            this.label2.Click += new System.EventHandler(this.Label2_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.label3.Location = new System.Drawing.Point(241, 152);
            this.label3.Name = "label3";
            this.label3.Padding = new System.Windows.Forms.Padding(7);
            this.label3.Size = new System.Drawing.Size(44, 27);
            this.label3.TabIndex = 18;
            this.label3.Text = "Wed";
            this.label3.Click += new System.EventHandler(this.Label3_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.label4.Location = new System.Drawing.Point(188, 229);
            this.label4.Name = "label4";
            this.label4.Padding = new System.Windows.Forms.Padding(7);
            this.label4.Size = new System.Drawing.Size(40, 27);
            this.label4.TabIndex = 19;
            this.label4.Text = "Thu";
            this.label4.Click += new System.EventHandler(this.Label4_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.label5.Location = new System.Drawing.Point(100, 229);
            this.label5.Name = "label5";
            this.label5.Padding = new System.Windows.Forms.Padding(7);
            this.label5.Size = new System.Drawing.Size(32, 27);
            this.label5.TabIndex = 20;
            this.label5.Text = "Fri";
            this.label5.Click += new System.EventHandler(this.Label5_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.label6.Location = new System.Drawing.Point(31, 152);
            this.label6.Name = "label6";
            this.label6.Padding = new System.Windows.Forms.Padding(7);
            this.label6.Size = new System.Drawing.Size(37, 27);
            this.label6.TabIndex = 21;
            this.label6.Text = "Sat";
            this.label6.Click += new System.EventHandler(this.Label6_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.label7.Location = new System.Drawing.Point(50, 77);
            this.label7.Name = "label7";
            this.label7.Padding = new System.Windows.Forms.Padding(7);
            this.label7.Size = new System.Drawing.Size(40, 27);
            this.label7.TabIndex = 22;
            this.label7.Text = "Sun";
            this.label7.Click += new System.EventHandler(this.Label7_Click);
            // 
            // clock
            // 
            this.clock.AutoSize = true;
            this.clock.Location = new System.Drawing.Point(112, 293);
            this.clock.Name = "clock";
            this.clock.Size = new System.Drawing.Size(41, 13);
            this.clock.TabIndex = 30;
            this.clock.Text = "label10";
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.clock);
            this.panel4.Controls.Add(this.pictureBox7);
            this.panel4.Controls.Add(this.pictureBox6);
            this.panel4.Controls.Add(this.pictureBox5);
            this.panel4.Controls.Add(this.pictureBox4);
            this.panel4.Controls.Add(this.pictureBox3);
            this.panel4.Controls.Add(this.pictureBox2);
            this.panel4.Controls.Add(this.pictureBox1);
            this.panel4.Controls.Add(this.label7);
            this.panel4.Controls.Add(this.label6);
            this.panel4.Controls.Add(this.label5);
            this.panel4.Controls.Add(this.label4);
            this.panel4.Controls.Add(this.label3);
            this.panel4.Controls.Add(this.label2);
            this.panel4.Controls.Add(this.label1);
            this.panel4.Location = new System.Drawing.Point(1399, 34);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(319, 326);
            this.panel4.TabIndex = 18;
            // 
            // pictureBox7
            // 
            this.pictureBox7.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox7.Image")));
            this.pictureBox7.Location = new System.Drawing.Point(96, 85);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Size = new System.Drawing.Size(71, 70);
            this.pictureBox7.TabIndex = 29;
            this.pictureBox7.TabStop = false;
            // 
            // pictureBox6
            // 
            this.pictureBox6.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox6.Image")));
            this.pictureBox6.Location = new System.Drawing.Point(74, 124);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(87, 55);
            this.pictureBox6.TabIndex = 28;
            this.pictureBox6.TabStop = false;
            // 
            // pictureBox5
            // 
            this.pictureBox5.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox5.Image")));
            this.pictureBox5.Location = new System.Drawing.Point(103, 139);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(65, 79);
            this.pictureBox5.TabIndex = 27;
            this.pictureBox5.TabStop = false;
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox4.Image")));
            this.pictureBox4.Location = new System.Drawing.Point(141, 139);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(73, 87);
            this.pictureBox4.TabIndex = 26;
            this.pictureBox4.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.Location = new System.Drawing.Point(135, 124);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(100, 50);
            this.pictureBox3.TabIndex = 25;
            this.pictureBox3.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(103, 63);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(111, 92);
            this.pictureBox2.TabIndex = 24;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(141, 41);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(32, 92);
            this.pictureBox1.TabIndex = 23;
            this.pictureBox1.TabStop = false;
            // 
            // panel5
            // 
            this.panel5.Controls.Add(this.pictureBox13);
            this.panel5.Controls.Add(this.pictureBox12);
            this.panel5.Controls.Add(this.pictureBox11);
            this.panel5.Controls.Add(this.show_details);
            this.panel5.Controls.Add(this.pictureBox10);
            this.panel5.Controls.Add(this.pictureBox9);
            this.panel5.Controls.Add(this.news_title);
            this.panel5.Controls.Add(this.published_at);
            this.panel5.Controls.Add(this.SourceLabel);
            this.panel5.Controls.Add(this.news_details);
            this.panel5.Controls.Add(this.news_pic);
            this.panel5.Location = new System.Drawing.Point(1399, 454);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(431, 344);
            this.panel5.TabIndex = 22;
            // 
            // pictureBox13
            // 
            this.pictureBox13.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox13.Image")));
            this.pictureBox13.Location = new System.Drawing.Point(347, 179);
            this.pictureBox13.Name = "pictureBox13";
            this.pictureBox13.Size = new System.Drawing.Size(34, 34);
            this.pictureBox13.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox13.TabIndex = 28;
            this.pictureBox13.TabStop = false;
            this.pictureBox13.Click += new System.EventHandler(this.Refresh_Click);
            // 
            // pictureBox12
            // 
            this.pictureBox12.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox12.Image")));
            this.pictureBox12.Location = new System.Drawing.Point(3, 4);
            this.pictureBox12.Name = "pictureBox12";
            this.pictureBox12.Size = new System.Drawing.Size(39, 36);
            this.pictureBox12.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox12.TabIndex = 27;
            this.pictureBox12.TabStop = false;
            this.pictureBox12.Click += new System.EventHandler(this.Previous_Click);
            // 
            // pictureBox11
            // 
            this.pictureBox11.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox11.Image")));
            this.pictureBox11.Location = new System.Drawing.Point(395, 4);
            this.pictureBox11.Name = "pictureBox11";
            this.pictureBox11.Size = new System.Drawing.Size(33, 35);
            this.pictureBox11.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox11.TabIndex = 26;
            this.pictureBox11.TabStop = false;
            this.pictureBox11.Click += new System.EventHandler(this.Next_Click);
            // 
            // show_details
            // 
            this.show_details.Location = new System.Drawing.Point(261, 179);
            this.show_details.Name = "show_details";
            this.show_details.Size = new System.Drawing.Size(80, 29);
            this.show_details.TabIndex = 25;
            this.show_details.Text = "Show Details";
            this.show_details.UseVisualStyleBackColor = true;
            this.show_details.Click += new System.EventHandler(this.Show_details_Click);
            // 
            // pictureBox10
            // 
            this.pictureBox10.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox10.Image")));
            this.pictureBox10.Location = new System.Drawing.Point(347, 92);
            this.pictureBox10.Name = "pictureBox10";
            this.pictureBox10.Size = new System.Drawing.Size(63, 65);
            this.pictureBox10.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox10.TabIndex = 24;
            this.pictureBox10.TabStop = false;
            this.pictureBox10.Click += new System.EventHandler(this.Next_article_Click);
            // 
            // pictureBox9
            // 
            this.pictureBox9.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox9.Image")));
            this.pictureBox9.Location = new System.Drawing.Point(2, 92);
            this.pictureBox9.Name = "pictureBox9";
            this.pictureBox9.Size = new System.Drawing.Size(64, 65);
            this.pictureBox9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox9.TabIndex = 23;
            this.pictureBox9.TabStop = false;
            this.pictureBox9.Click += new System.EventHandler(this.prev_article);
            // 
            // news_title
            // 
            this.news_title.Location = new System.Drawing.Point(188, 127);
            this.news_title.Name = "news_title";
            this.news_title.ReadOnly = true;
            this.news_title.Size = new System.Drawing.Size(153, 46);
            this.news_title.TabIndex = 23;
            this.news_title.Text = "";
            // 
            // published_at
            // 
            this.published_at.AutoSize = true;
            this.published_at.Location = new System.Drawing.Point(188, 102);
            this.published_at.Name = "published_at";
            this.published_at.Size = new System.Drawing.Size(69, 13);
            this.published_at.TabIndex = 22;
            this.published_at.Text = "Published At:";
            // 
            // SourceLabel
            // 
            this.SourceLabel.AutoSize = true;
            this.SourceLabel.Location = new System.Drawing.Point(188, 73);
            this.SourceLabel.Name = "SourceLabel";
            this.SourceLabel.Size = new System.Drawing.Size(44, 13);
            this.SourceLabel.TabIndex = 20;
            this.SourceLabel.Text = "Source:";
            this.SourceLabel.Click += new System.EventHandler(this.SourceLabel_Click);
            // 
            // news_details
            // 
            this.news_details.Location = new System.Drawing.Point(72, 214);
            this.news_details.Name = "news_details";
            this.news_details.ReadOnly = true;
            this.news_details.Size = new System.Drawing.Size(269, 113);
            this.news_details.TabIndex = 18;
            this.news_details.Text = "";
            // 
            // news_pic
            // 
            this.news_pic.Location = new System.Drawing.Point(72, 73);
            this.news_pic.Name = "news_pic";
            this.news_pic.Size = new System.Drawing.Size(110, 100);
            this.news_pic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.news_pic.TabIndex = 17;
            this.news_pic.TabStop = false;
            // 
            // pictureBox14
            // 
            this.pictureBox14.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox14.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox14.Image")));
            this.pictureBox14.Location = new System.Drawing.Point(1368, 163);
            this.pictureBox14.Name = "pictureBox14";
            this.pictureBox14.Size = new System.Drawing.Size(34, 25);
            this.pictureBox14.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox14.TabIndex = 25;
            this.pictureBox14.TabStop = false;
            this.pictureBox14.Click += new System.EventHandler(this.youtube_click);
            // 
            // linkedin
            // 
            this.linkedin.Cursor = System.Windows.Forms.Cursors.Hand;
            this.linkedin.Image = ((System.Drawing.Image)(resources.GetObject("linkedin.Image")));
            this.linkedin.Location = new System.Drawing.Point(1368, 125);
            this.linkedin.Name = "linkedin";
            this.linkedin.Size = new System.Drawing.Size(34, 37);
            this.linkedin.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.linkedin.TabIndex = 21;
            this.linkedin.TabStop = false;
            this.linkedin.Click += new System.EventHandler(this.Linkedin_Click);
            // 
            // twitter
            // 
            this.twitter.Cursor = System.Windows.Forms.Cursors.Hand;
            this.twitter.Image = ((System.Drawing.Image)(resources.GetObject("twitter.Image")));
            this.twitter.Location = new System.Drawing.Point(1368, 90);
            this.twitter.Name = "twitter";
            this.twitter.Size = new System.Drawing.Size(34, 37);
            this.twitter.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.twitter.TabIndex = 20;
            this.twitter.TabStop = false;
            this.twitter.Click += new System.EventHandler(this.Twitter_Click);
            // 
            // facebook
            // 
            this.facebook.Cursor = System.Windows.Forms.Cursors.Hand;
            this.facebook.Image = ((System.Drawing.Image)(resources.GetObject("facebook.Image")));
            this.facebook.Location = new System.Drawing.Point(1368, 55);
            this.facebook.Name = "facebook";
            this.facebook.Size = new System.Drawing.Size(34, 36);
            this.facebook.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.facebook.TabIndex = 19;
            this.facebook.TabStop = false;
            this.facebook.Click += new System.EventHandler(this.Facebook_Click);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(82, 90);
            this.textBox1.Name = "textBox1";
            this.textBox1.PasswordChar = '*';
            this.textBox1.Size = new System.Drawing.Size(314, 20);
            this.textBox1.TabIndex = 0;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(82, 54);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(314, 20);
            this.textBox2.TabIndex = 1;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(340, 116);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(56, 25);
            this.button2.TabIndex = 2;
            this.button2.Text = "Submit";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.email_submit_Click);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(40, 57);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(36, 13);
            this.label10.TabIndex = 3;
            this.label10.Text = "Gmail:";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(20, 93);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(56, 13);
            this.label11.TabIndex = 4;
            this.label11.Text = "Password:";
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(82, 16);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(314, 20);
            this.textBox3.TabIndex = 5;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(38, 19);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(38, 13);
            this.label12.TabIndex = 6;
            this.label12.Text = "Name:";
            // 
            // panel6
            // 
            this.panel6.Controls.Add(this.label12);
            this.panel6.Controls.Add(this.textBox3);
            this.panel6.Controls.Add(this.label11);
            this.panel6.Controls.Add(this.label10);
            this.panel6.Controls.Add(this.button2);
            this.panel6.Controls.Add(this.textBox2);
            this.panel6.Controls.Add(this.textBox1);
            this.panel6.Location = new System.Drawing.Point(65, 383);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(415, 157);
            this.panel6.TabIndex = 23;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(239, 26);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(63, 13);
            this.label13.TabIndex = 27;
            this.label13.Text = "Contact List";
            this.label13.Click += new System.EventHandler(this.Label13_Click);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(248, 289);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(85, 13);
            this.label14.TabIndex = 28;
            this.label14.Text = "Joining Contacts";
            // 
            // combo_contacts
            // 
            this.combo_contacts.FormattingEnabled = true;
            this.combo_contacts.Location = new System.Drawing.Point(242, 53);
            this.combo_contacts.Name = "combo_contacts";
            this.combo_contacts.Size = new System.Drawing.Size(440, 21);
            this.combo_contacts.TabIndex = 29;
            // 
            // combo_joining_contacts
            // 
            this.combo_joining_contacts.FormattingEnabled = true;
            this.combo_joining_contacts.Location = new System.Drawing.Point(251, 314);
            this.combo_joining_contacts.Name = "combo_joining_contacts";
            this.combo_joining_contacts.Size = new System.Drawing.Size(440, 21);
            this.combo_joining_contacts.TabIndex = 30;
            // 
            // panel7
            // 
            this.panel7.Controls.Add(this.SubjectName);
            this.panel7.Controls.Add(this.Subject);
            this.panel7.Controls.Add(this.retrieve);
            this.panel7.Controls.Add(this.Send);
            this.panel7.Controls.Add(this.label18);
            this.panel7.Controls.Add(this.coeditor_mail);
            this.panel7.Controls.Add(this.Coeditor);
            this.panel7.Controls.Add(this.remove_mail);
            this.panel7.Controls.Add(this.add_button);
            this.panel7.Controls.Add(this.remove_button);
            this.panel7.Controls.Add(this.remove_email);
            this.panel7.Controls.Add(this.label17);
            this.panel7.Controls.Add(this.label16);
            this.panel7.Controls.Add(this.label15);
            this.panel7.Controls.Add(this.Name);
            this.panel7.Controls.Add(this.surname_text);
            this.panel7.Controls.Add(this.email_text);
            this.panel7.Controls.Add(this.number_text);
            this.panel7.Controls.Add(this.name_text);
            this.panel7.Controls.Add(this.combo_contacts);
            this.panel7.Controls.Add(this.combo_joining_contacts);
            this.panel7.Controls.Add(this.label13);
            this.panel7.Controls.Add(this.label14);
            this.panel7.Location = new System.Drawing.Point(559, 34);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(710, 455);
            this.panel7.TabIndex = 31;
            // 
            // SubjectName
            // 
            this.SubjectName.Location = new System.Drawing.Point(323, 200);
            this.SubjectName.Name = "SubjectName";
            this.SubjectName.Size = new System.Drawing.Size(100, 20);
            this.SubjectName.TabIndex = 50;
            // 
            // Subject
            // 
            this.Subject.AutoSize = true;
            this.Subject.Location = new System.Drawing.Point(262, 207);
            this.Subject.Name = "Subject";
            this.Subject.Size = new System.Drawing.Size(46, 13);
            this.Subject.TabIndex = 49;
            this.Subject.Text = "Subject:";
            // 
            // retrieve
            // 
            this.retrieve.Location = new System.Drawing.Point(251, 229);
            this.retrieve.Name = "retrieve";
            this.retrieve.Size = new System.Drawing.Size(172, 33);
            this.retrieve.TabIndex = 48;
            this.retrieve.Text = "Check the Joining Contacts";
            this.retrieve.UseVisualStyleBackColor = true;
            this.retrieve.Click += new System.EventHandler(this.Retrieve_Click);
            // 
            // Send
            // 
            this.Send.Location = new System.Drawing.Point(539, 100);
            this.Send.Name = "Send";
            this.Send.Size = new System.Drawing.Size(143, 33);
            this.Send.TabIndex = 47;
            this.Send.Text = "Send to Contact List";
            this.Send.UseVisualStyleBackColor = true;
            this.Send.Click += new System.EventHandler(this.Send_Click);
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(35, 324);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(39, 13);
            this.label18.TabIndex = 46;
            this.label18.Text = "E-Mail:";
            // 
            // coeditor_mail
            // 
            this.coeditor_mail.Location = new System.Drawing.Point(95, 317);
            this.coeditor_mail.Name = "coeditor_mail";
            this.coeditor_mail.Size = new System.Drawing.Size(100, 20);
            this.coeditor_mail.TabIndex = 45;
            // 
            // Coeditor
            // 
            this.Coeditor.Location = new System.Drawing.Point(120, 358);
            this.Coeditor.Name = "Coeditor";
            this.Coeditor.Size = new System.Drawing.Size(75, 23);
            this.Coeditor.TabIndex = 44;
            this.Coeditor.Text = "Co-Editor";
            this.Coeditor.UseVisualStyleBackColor = true;
            this.Coeditor.Click += new System.EventHandler(this.Coeditor_Click);
            // 
            // remove_mail
            // 
            this.remove_mail.AutoSize = true;
            this.remove_mail.Location = new System.Drawing.Point(35, 232);
            this.remove_mail.Name = "remove_mail";
            this.remove_mail.Size = new System.Drawing.Size(39, 13);
            this.remove_mail.TabIndex = 43;
            this.remove_mail.Text = "E-Mail:";
            this.remove_mail.Click += new System.EventHandler(this.Remove_mail_Click);
            // 
            // add_button
            // 
            this.add_button.Location = new System.Drawing.Point(119, 175);
            this.add_button.Name = "add_button";
            this.add_button.Size = new System.Drawing.Size(75, 23);
            this.add_button.TabIndex = 42;
            this.add_button.Text = "Add";
            this.add_button.UseVisualStyleBackColor = true;
            this.add_button.Click += new System.EventHandler(this.Add_button_Click);
            // 
            // remove_button
            // 
            this.remove_button.Location = new System.Drawing.Point(120, 260);
            this.remove_button.Name = "remove_button";
            this.remove_button.Size = new System.Drawing.Size(75, 23);
            this.remove_button.TabIndex = 41;
            this.remove_button.Text = "Remove";
            this.remove_button.UseVisualStyleBackColor = true;
            this.remove_button.Click += new System.EventHandler(this.Remove_button_Click);
            // 
            // remove_email
            // 
            this.remove_email.Location = new System.Drawing.Point(95, 225);
            this.remove_email.Name = "remove_email";
            this.remove_email.Size = new System.Drawing.Size(100, 20);
            this.remove_email.TabIndex = 39;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(27, 141);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(47, 13);
            this.label17.TabIndex = 38;
            this.label17.Text = "Number:";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(27, 104);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(39, 13);
            this.label16.TabIndex = 37;
            this.label16.Text = "E-Mail:";
            this.label16.Click += new System.EventHandler(this.Label16_Click);
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(22, 67);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(52, 13);
            this.label15.TabIndex = 36;
            this.label15.Text = "Surname:";
            // 
            // Name
            // 
            this.Name.AutoSize = true;
            this.Name.Location = new System.Drawing.Point(22, 25);
            this.Name.Name = "Name";
            this.Name.Size = new System.Drawing.Size(38, 13);
            this.Name.TabIndex = 35;
            this.Name.Text = "Name:";
            // 
            // surname_text
            // 
            this.surname_text.Location = new System.Drawing.Point(95, 60);
            this.surname_text.Name = "surname_text";
            this.surname_text.Size = new System.Drawing.Size(100, 20);
            this.surname_text.TabIndex = 34;
            // 
            // email_text
            // 
            this.email_text.Location = new System.Drawing.Point(95, 97);
            this.email_text.Name = "email_text";
            this.email_text.Size = new System.Drawing.Size(100, 20);
            this.email_text.TabIndex = 33;
            // 
            // number_text
            // 
            this.number_text.Location = new System.Drawing.Point(95, 135);
            this.number_text.Name = "number_text";
            this.number_text.Size = new System.Drawing.Size(100, 20);
            this.number_text.TabIndex = 32;
            // 
            // name_text
            // 
            this.name_text.Location = new System.Drawing.Point(95, 26);
            this.name_text.Name = "name_text";
            this.name_text.Size = new System.Drawing.Size(100, 20);
            this.name_text.TabIndex = 31;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1562, 652);
            this.Controls.Add(this.panel7);
            this.Controls.Add(this.pictureBox14);
            this.Controls.Add(this.panel6);
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.linkedin);
            this.Controls.Add(this.twitter);
            this.Controls.Add(this.facebook);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.Form1_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox13)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.news_pic)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox14)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.linkedin)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.twitter)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.facebook)).EndInit();
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            this.panel7.ResumeLayout(false);
            this.panel7.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label am_23;
        private System.Windows.Forms.Label am_22;
        private System.Windows.Forms.Label am_21;
        private System.Windows.Forms.Label am_20;
        private System.Windows.Forms.Label am_19;
        private System.Windows.Forms.Label am_18;
        private System.Windows.Forms.Label am_17;
        private System.Windows.Forms.Label am_16;
        private System.Windows.Forms.Label am_15;
        private System.Windows.Forms.Label am_14;
        private System.Windows.Forms.Label am_13;
        private System.Windows.Forms.Label am_24;
        private System.Windows.Forms.Label am_11;
        private System.Windows.Forms.Label am_10;
        private System.Windows.Forms.Label am_9;
        private System.Windows.Forms.Label am_8;
        private System.Windows.Forms.Label am_7;
        private System.Windows.Forms.Label am_6;
        private System.Windows.Forms.Label am_5;
        private System.Windows.Forms.Label am_4;
        private System.Windows.Forms.Label am_3;
        private System.Windows.Forms.Label am_2;
        private System.Windows.Forms.Label am_1;
        private System.Windows.Forms.Label am_12;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button delete_activity;
        private System.Windows.Forms.Label activity_label;
        private System.Windows.Forms.Button new_activity_button;
        private System.Windows.Forms.Label activity_list;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Button add;
        private System.Windows.Forms.RichTextBox richTextBox1;
        private System.Windows.Forms.PictureBox pictureBox8;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.PictureBox pictureBox7;
        private System.Windows.Forms.Label clock;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.PictureBox facebook;
        private System.Windows.Forms.PictureBox twitter;
        private System.Windows.Forms.PictureBox linkedin;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button send_mail;
        private System.Windows.Forms.Label label_content;
        private System.Windows.Forms.RichTextBox content_textbox;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.RichTextBox news_details;
        private System.Windows.Forms.PictureBox news_pic;
        private System.Windows.Forms.Label SourceLabel;
        private System.Windows.Forms.RichTextBox news_title;
        private System.Windows.Forms.Label published_at;
        private System.Windows.Forms.PictureBox pictureBox10;
        private System.Windows.Forms.PictureBox pictureBox9;
        private System.Windows.Forms.Button show_details;
        private System.Windows.Forms.PictureBox pictureBox11;
        private System.Windows.Forms.PictureBox pictureBox12;
        private System.Windows.Forms.PictureBox pictureBox13;
        private System.Windows.Forms.PictureBox pictureBox14;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.ComboBox combo_contacts;
        private System.Windows.Forms.ComboBox combo_joining_contacts;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.TextBox surname_text;
        private System.Windows.Forms.TextBox email_text;
        private System.Windows.Forms.TextBox number_text;
        private System.Windows.Forms.TextBox name_text;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label Name;
        private System.Windows.Forms.Button remove_button;
        private System.Windows.Forms.TextBox remove_email;
        private System.Windows.Forms.Label remove_mail;
        private System.Windows.Forms.Button add_button;
        private System.Windows.Forms.TextBox coeditor_mail;
        private System.Windows.Forms.Button Coeditor;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Button retrieve;
        private System.Windows.Forms.Button Send;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.RichTextBox mailSubject;
        private System.Windows.Forms.TextBox SubjectName;
        private System.Windows.Forms.Label Subject;
    }
}

