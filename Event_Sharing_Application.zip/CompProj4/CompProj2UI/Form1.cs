﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Text;
using System.Xml;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Globalization;

using Twilio; // for whatsapp api
using Twilio.Rest.Api.V2010.Account;
using Twilio.Types;
using EAGetMail;//for retrieving mails




namespace CompProj2UI
{
    public partial class Form1 : Form
    {

        Timer timer = new Timer();
        public string[] colorPreferences = { "Red", "Blue", "Green", "Purple", "White" };
        const string bbc = "https://newsapi.org/v2/top-headlines?" +
          "sources=bbc-news&" +
          "apiKey=abfb6e3b6d4644ecb8a8ce68bd3c0f7a";

        const string bbc_sport = "https://newsapi.org/v2/top-headlines?" +
          "sources=bbc-sport&" +
          "apiKey=abfb6e3b6d4644ecb8a8ce68bd3c0f7a";
        const string tech = "https://newsapi.org/v2/top-headlines?sources=techcrunch&apiKey=abfb6e3b6d4644ecb8a8ce68bd3c0f7a";
        const string haberturk = "https://newsapi.org/v2/top-headlines?country=tr&apiKey=abfb6e3b6d4644ecb8a8ce68bd3c0f7a";

        private const string API_KEY = "5a45d7381500dcf754e25bc99126df4a";
        List<string> mon_hour = new List<string>();
        List<string> mon_temp = new List<string>();
        List<string> tue_hour = new List<string>();
        List<string> tue_temp = new List<string>();
        List<string> wed_hour = new List<string>();
        List<string> wed_temp = new List<string>();
        List<string> thu_hour = new List<string>();
        List<string> thu_temp = new List<string>();
        List<string> fri_hour = new List<string>();
        List<string> fri_temp = new List<string>();
        List<string> sat_hour = new List<string>();
        List<string> sat_temp = new List<string>();
        List<string> sun_hour = new List<string>();
        List<string> sun_temp = new List<string>();

        List<string> URL_Connection;
        public int NewsCounter { get; set; } = 0;
        public int SourceCounter { get; set; } = 0;
        public News.Rootobject Root { get; set; }


        
        List<string> user_name = new List<string>();
        List<string> user_surname = new List<string>();
        List<string> user_mail = new List<string>();
        List<string> user_number = new List<string>();

        List<string> user_name_joining = new List<string>();
        List<string> user_surname_joining = new List<string>();
        List<string> user_mail_joining = new List<string>();
        List<string> user_number_joining = new List<string>();

        List<string> user_context_joining = new List<string>();
        public string strFilePath = @"./contacts.csv";
        public string strFilePath2 = @"./joining_contacts.csv";
        public string strSeperator = ",";




        public Form1()
        {

            InitializeComponent();

            SetupList();
            CallAPI();

            timer.Tick += new EventHandler(Timer1_Tick);
            timer.Interval = (1000) * (1);
            timer.Enabled = true;
            timer.Start();


        }
        int day = 0;
        int[] mon_hours = new int[24] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
        String[] mon_activity = new String[24];
        int[] tue_hours = new int[24] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
        String[] tue_activity = new String[24];
        int[] wed_hours = new int[24] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
        String[] wed_activity = new String[24];
        int[] thu_hours = new int[24] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
        String[] thu_activity = new String[24];
        int[] fri_hours = new int[24] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
        String[] fri_activity = new String[24];
        int[] sat_hours = new int[24] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
        String[] sat_activity = new String[24];
        int[] sun_hours = new int[24] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
        String[] sun_activity = new String[24];
        Label clickedLabel;
        int selected_hour = 0;
        public string mail_subject;



        public string user = "";
        public string username = "";
        public string password = "";
        public string backcolor = "";


        private void SetupList()
        {
            this.URL_Connection = new List<string>();
            this.URL_Connection.Add(bbc);
            this.URL_Connection.Add(tech);
            this.URL_Connection.Add(haberturk);
            this.URL_Connection.Add(bbc_sport);
        }

        private async void CallAPI()
        {
            NewsCounter = 0;
            Root = await config.Deserialize(this.URL_Connection[SourceCounter]);
            SetupForm();

        }
        private void SetupForm()
        {
            //cleanup
            news_details.Text = string.Empty;// does not append description each time

            news_pic.Load(Root.articles[NewsCounter].urlToImage);
            SourceLabel.Text = Root.articles[NewsCounter].source.name;
            published_at.Text = ($"{Root.articles[NewsCounter].publishedAt}{Environment.NewLine}");
            news_title.Text = (Root.articles[NewsCounter].title);
            news_details.AppendText(Root.articles[NewsCounter].description);
            news_details.Visible = false;

        }

        public class http
        {
            public static async Task<string> GetAsync(string uri)
            {
                HttpWebRequest request = (HttpWebRequest)WebRequest.Create(uri);
                using (HttpWebResponse response = (HttpWebResponse)await request.GetResponseAsync())
                using (Stream stream = response.GetResponseStream())
                using (StreamReader reader = new StreamReader(stream))
                {
                    return await reader.ReadToEndAsync();
                }
            }
        }
        public class config
        {
            public static async Task<News.Rootobject> Deserialize(string URI)
            {
                var json = await http.GetAsync(URI);
                return Newtonsoft.Json.JsonConvert.DeserializeObject<News.Rootobject>(json);
            }
        }

        public class News
        {

            public class Rootobject
            {
                public string status { get; set; }
                public int totalResults { get; set; }
                public Article[] articles { get; set; }
            }

            public class Article
            {
                public Source source { get; set; }
                public string author { get; set; }
                public string title { get; set; }
                public string description { get; set; }
                public string url { get; set; }
                public string urlToImage { get; set; }
                public DateTime publishedAt { get; set; }
                public string content { get; set; }
            }

            public class Source
            {
                public string id { get; set; }
                public string name { get; set; }
            }

        }

        private void prev_article(object sender, EventArgs e)
        {
            if (NewsCounter > 0)
            {
                this.NewsCounter--;
                SetupForm();
            }
        }

        private void Next_article_Click(object sender, EventArgs e)
        {
            if (NewsCounter < 9)
            {
                this.NewsCounter++;
                SetupForm();
            }
        }

        private void Previous_Click(object sender, EventArgs e)
        {
            if (SourceCounter > 0)
            {
                this.SourceCounter--;
                CallAPI();
            }
        }

        private void Next_Click(object sender, EventArgs e)
        {
            if (SourceCounter < URL_Connection.Count - 1)
            {
                this.SourceCounter++;
                CallAPI();
            }
        }

        private void Refresh_Click(object sender, EventArgs e)
        {
            CallAPI();
            MessageBox.Show("all data up to date");
        }


        public void color_days()
        {

            int busy_mon = 0, busy_tue = 0, busy_wed = 0, busy_thu = 0, busy_fri = 0, busy_sat = 0, busy_sun = 0;
            for (int j = 0; j < 24; j++)
            {
                busy_mon += mon_hours[j];
                busy_tue += tue_hours[j];
                busy_wed += wed_hours[j];
                busy_thu += thu_hours[j];
                busy_fri += fri_hours[j];
                busy_sat += sat_hours[j];
                busy_sun += sun_hours[j];
            }
            Color col;
            col = Color.FromArgb(255, 180 - 5 * busy_mon, 180 - 5 * busy_mon);
            label1.BackColor = col;
            col = Color.FromArgb(255, 180 - 5 * busy_mon, 180 - 5 * busy_tue);
            label2.BackColor = col;
            col = Color.FromArgb(255, 180 - 5 * busy_mon, 180 - 5 * busy_wed);
            label3.BackColor = col;
            col = Color.FromArgb(255, 180 - 5 * busy_mon, 180 - 5 * busy_thu);
            label4.BackColor = col;
            col = Color.FromArgb(255, 180 - 5 * busy_mon, 180 - 5 * busy_fri);
            label5.BackColor = col;
            col = Color.FromArgb(255, 180 - 5 * busy_mon, 180 - 5 * busy_sat);
            label6.BackColor = col;
            col = Color.FromArgb(255, 180 - 5 * busy_mon, 180 - 5 * busy_sun);
            label7.BackColor = col;
        }
      

        private void Form1_Load(object sender, EventArgs e)
        {


            panel7.Visible = false;

            if (File.Exists(strFilePath2))
            {
                combo_joining_contacts.Items.Clear();
                using (var reader_joining = new StreamReader(strFilePath2))
                {
                    while (!reader_joining.EndOfStream)
                    {
                        var line = reader_joining.ReadLine();
                        var values_joining = line.Split(',');
                        user_name_joining.Add(values_joining[0]);
                        user_surname_joining.Add(values_joining[1]);
                        user_mail_joining.Add(values_joining[2]);
                        user_context_joining.Add(values_joining[3]);
                        user_number_joining.Add(values_joining[4]);
                    }
                }
                for (int i = 0; i < user_number_joining.Count; i++)
                    combo_joining_contacts.Items.Add(i.ToString() + " " + user_name_joining[i] + " " + user_surname_joining[i] + " " + "+" + user_number_joining[i] + " " + user_mail_joining[i] + " "+ user_context_joining[i]);
            }

            if (File.Exists(strFilePath))
            {
                combo_contacts.Items.Clear();
                using (var reader = new StreamReader(strFilePath))
                {
                    while (!reader.EndOfStream)
                    {
                        var line = reader.ReadLine();
                        var values = line.Split(',');
                        user_name.Add(values[0]);
                        user_surname.Add(values[1]);
                        user_mail.Add(values[2]);
                        user_number.Add(values[3]);

                    }
                }
                for (int i = 0; i < user_name.Count; i++)
                    combo_contacts.Items.Add(i.ToString() + " " + user_name[i] + " " + user_surname[i] + " "  + "+" + user_number[i] + " " + user_mail[i]);
            }





            DayOfWeek today = DateTime.Today.DayOfWeek;
            panel1.Visible = false;
            panel2.Visible = false;
            panel3.Visible = false;
            panel5.Visible = true;
          

            color_days();


            pictureBox1.Visible = false;
            pictureBox2.Visible = false;
            pictureBox3.Visible = false;
            pictureBox4.Visible = false;
            pictureBox5.Visible = false;
            pictureBox6.Visible = false;
            pictureBox7.Visible = false;


            panel1.BackColor = Color.FromName(backcolor);
            panel2.BackColor = Color.FromName(backcolor);
            panel3.BackColor = Color.FromName(backcolor);
            panel4.BackColor = Color.FromName(backcolor);
            panel5.BackColor = Color.FromName(backcolor);
         





            if (today == DayOfWeek.Monday)
                pictureBox1.Visible = true;
            else if (today == DayOfWeek.Tuesday)
                pictureBox2.Visible = true;
            else if (today == DayOfWeek.Wednesday)
                pictureBox3.Visible = true;
            else if (today == DayOfWeek.Thursday)
                pictureBox4.Visible = true;
            else if (today == DayOfWeek.Friday)
                pictureBox5.Visible = true;
            else if (today == DayOfWeek.Saturday)
                pictureBox6.Visible = true;
            else if (today == DayOfWeek.Sunday)
                pictureBox7.Visible = true;

            for (int i = 1; i < 25; i++)
            {
                Control match = this.Controls.Find("am_" + (i).ToString(), true).FirstOrDefault();
                if (match != null)
                {
                    match.BackColor = Color.Green;
                }
            }

        }

        private void Form1_FormClosing(Object sender, FormClosingEventArgs e)
        {
           


            if (e.CloseReason == CloseReason.WindowsShutDown) return;

            // Confirm user wants to close
            switch (MessageBox.Show(this, "Are you sure you want to close?", "Closing", MessageBoxButtons.YesNo))
            {
                case DialogResult.No:
                    e.Cancel = true;
                    break;
                default:
                    break;
            }


        }


        private void Label1_Click(object sender, EventArgs e) //monday
        {

            day = 1; //monday is clicked
            for (int i = 1; i < 25; i++)
            {
                Control match = this.Controls.Find("am_" + (i).ToString(), true).FirstOrDefault();
                if (match != null)
                {
                    if (mon_hours[i - 1] == 0)
                    {
                        match.BackColor = Color.Green;
                    }
                    else
                    {
                        match.BackColor = Color.Red;
                    }
                }

            }
            panel1.Visible = true;
        }

        private void Label2_Click(object sender, EventArgs e)//tuesday
        {
            day = 2; //tue is clicked

            for (int i = 1; i < 25; i++)
            {
                Control match = this.Controls.Find("am_" + (i).ToString(), true).FirstOrDefault();
                if (match != null)
                {
                    if (tue_hours[i - 1] == 0)
                    {
                        match.BackColor = Color.Green;
                    }
                    else
                    {
                        match.BackColor = Color.Red;
                    }
                }

            }
            panel1.Visible = true;
        }

        private void Label3_Click(object sender, EventArgs e)
        {
            day = 3;
            for (int i = 1; i < 25; i++)
            {
                Control match = this.Controls.Find("am_" + (i).ToString(), true).FirstOrDefault();
                if (match != null)
                {
                    if (wed_hours[i - 1] == 0)
                    {
                        match.BackColor = Color.Green;
                    }
                    else
                    {
                        match.BackColor = Color.Red;
                    }
                }

            }
            panel1.Visible = true;
        }
        private void Label4_Click(object sender, EventArgs e)
        {
            day = 4;
            for (int i = 1; i < 25; i++)
            {
                Control match = this.Controls.Find("am_" + (i).ToString(), true).FirstOrDefault();
                if (match != null)
                {
                    if (thu_hours[i - 1] == 0)
                    {
                        match.BackColor = Color.Green;
                    }
                    else
                    {
                        match.BackColor = Color.Red;
                    }
                }

            }
            panel1.Visible = true;
        }
        private void Label5_Click(object sender, EventArgs e)
        {
            day = 5;
            for (int i = 1; i < 25; i++)
            {
                Control match = this.Controls.Find("am_" + (i).ToString(), true).FirstOrDefault();
                if (match != null)
                {
                    if (fri_hours[i - 1] == 0)
                    {
                        match.BackColor = Color.Green;
                    }
                    else
                    {
                        match.BackColor = Color.Red;
                    }
                }

            }
            panel1.Visible = true;
        }
        private void Label6_Click(object sender, EventArgs e)
        {
            day = 6;
            for (int i = 1; i < 25; i++)
            {
                Control match = this.Controls.Find("am_" + (i).ToString(), true).FirstOrDefault();
                if (match != null)
                {
                    if (sat_hours[i - 1] == 0)
                    {
                        match.BackColor = Color.Green;
                    }
                    else
                    {
                        match.BackColor = Color.Red;
                    }
                }

            }
            panel1.Visible = true;
        }
        private void Label7_Click(object sender, EventArgs e)
        {
            day = 7;
            for (int i = 1; i < 25; i++)
            {
                Control match = this.Controls.Find("am_" + (i).ToString(), true).FirstOrDefault();
                if (match != null)
                {
                    if (sun_hours[i - 1] == 0)
                    {
                        match.BackColor = Color.Green;
                    }
                    else
                    {
                        match.BackColor = Color.Red;
                    }
                }

            }
            panel1.Visible = true;
        }
        string old_color;
        private void new_activity(object sender, EventArgs e)
        {

            panel3.Visible = false;
            clickedLabel = sender as Label;
            panel2.Visible = true;

            for (int i = 1; i <= 24; i++)
            {
                Control match = this.Controls.Find("am_" + (i).ToString(), true).FirstOrDefault();
                if (match.BackColor == Color.Yellow)
                {
                    if (old_color == "red") match.BackColor = Color.Red;
                    else match.BackColor = Color.Green;
                    break;
                }
            }

            if (clickedLabel.BackColor == Color.Red) old_color = "red";
            else if (clickedLabel.BackColor == Color.Green) old_color = "green";
            clickedLabel.BackColor = Color.Yellow;
            int selected_hour = 0;
            for (int i = 1; i <= 24; i++)
            {
                Control match = this.Controls.Find("am_" + (i).ToString(), true).FirstOrDefault();
                if (clickedLabel == match)
                {
                    selected_hour = i;
                }
            }
            if (day == 1)
                activity_label.Text = mon_activity[selected_hour - 1];
            else if (day == 2)
                activity_label.Text = tue_activity[selected_hour - 1];
            else if (day == 3)
                activity_label.Text = wed_activity[selected_hour - 1];
            else if (day == 4)
                activity_label.Text = thu_activity[selected_hour - 1];
            else if (day == 5)
                activity_label.Text = fri_activity[selected_hour - 1];
            else if (day == 6)
                activity_label.Text = sat_activity[selected_hour - 1];
            else if (day == 7)
                activity_label.Text = sun_activity[selected_hour - 1];
            if (activity_label.Text == "no activity" || activity_label.Text == "'no activity'" || activity_label.Text == "")
            {
                button1.Enabled = false;
                new_activity_button.Text = "New Activity";
            }
            else
            {
                button1.Enabled = true;
                new_activity_button.Text = "Edit Activity";
            }

            mail_subject = activity_label.Text.ToString();
        }


        private void Panel1_Paint(object sender, PaintEventArgs e)
        {
        }

        private void Add_Click(object sender, EventArgs e)
        {

            for (int i = 1; i <= 24; i++)
            {
                Control match = this.Controls.Find("am_" + (i).ToString(), true).FirstOrDefault();
                if (clickedLabel.Name == match.Name)
                {
                    selected_hour = i;
                }
            }
            if (day == 1)
            {
                mon_activity[selected_hour - 1] = richTextBox1.Text.ToString();
                clickedLabel.BackColor = Color.Red;
                mon_hours[selected_hour - 1] = 1;
            }

            else if (day == 2)
            {
                tue_activity[selected_hour - 1] = richTextBox1.Text.ToString();
                clickedLabel.BackColor = Color.Red;
                tue_hours[selected_hour - 1] = 1;
            }
            else if (day == 3)
            {
                wed_activity[selected_hour - 1] = richTextBox1.Text.ToString();
                clickedLabel.BackColor = Color.Red;
                wed_hours[selected_hour - 1] = 1;
            }
            else if (day == 4)
            {
                thu_activity[selected_hour - 1] = richTextBox1.Text.ToString();
                clickedLabel.BackColor = Color.Red;
                thu_hours[selected_hour - 1] = 1;
            }
            else if (day == 5)
            {
                fri_activity[selected_hour - 1] = richTextBox1.Text.ToString();
                clickedLabel.BackColor = Color.Red;
                fri_hours[selected_hour - 1] = 1;
            }
            else if (day == 6)
            {
                sat_activity[selected_hour - 1] = richTextBox1.Text.ToString();
                clickedLabel.BackColor = Color.Red;
                sat_hours[selected_hour - 1] = 1;
            }
            else if (day == 7)
            {
                sun_activity[selected_hour - 1] = richTextBox1.Text.ToString();
                clickedLabel.BackColor = Color.Red;
                sun_hours[selected_hour - 1] = 1;
            }
            activity_label.Text = richTextBox1.Text;

            richTextBox1.Text = "";
            color_days();
            button1.Enabled = true;
            new_activity_button.Text = "Edit Activity";
            panel3.Visible = false;
        }

        private void New_activity_button_Click(object sender, EventArgs e)
        {
            panel3.Visible = true;
            label_content.Visible = false;
            label19.Visible = false;
            mailSubject.Visible = false;
            content_textbox.Visible = false;
            send_mail.Visible = false;

            richTextBox1.Visible = true;
            add.Visible = true;
        }

        private void Delete_activity_Click(object sender, EventArgs e)
        {
            label19.Visible = false;
            mailSubject.Visible = false;
            int selected_hour = 0;
            for (int i = 1; i <= 24; i++)
            {
                Control match = this.Controls.Find("am_" + (i).ToString(), true).FirstOrDefault();
                if (clickedLabel.Name == match.Name)
                {
                    selected_hour = i;
                }
            }
            if (day == 1)
            {
                mon_activity[selected_hour - 1] = "";
                clickedLabel.BackColor = Color.Green;
                mon_hours[selected_hour - 1] = 0;
            }

            else if (day == 2)
            {
                tue_activity[selected_hour - 1] = "";
                clickedLabel.BackColor = Color.Green;
                tue_hours[selected_hour - 1] = 0;
            }
            else if (day == 3)
            {
                wed_activity[selected_hour - 1] = "";
                clickedLabel.BackColor = Color.Green;
                wed_hours[selected_hour - 1] = 0;
            }
            else if (day == 4)
            {
                thu_activity[selected_hour - 1] = "";
                clickedLabel.BackColor = Color.Green;
                thu_hours[selected_hour - 1] = 0;
            }
            else if (day == 5)
            {
                fri_activity[selected_hour - 1] = "";
                clickedLabel.BackColor = Color.Green;
                fri_hours[selected_hour - 1] = 0;
            }
            else if (day == 6)
            {
                sat_activity[selected_hour - 1] = "";
                clickedLabel.BackColor = Color.Green;
                sat_hours[selected_hour - 1] = 0;
            }
            else if (day == 7)
            {
                sun_activity[selected_hour - 1] = "";
                clickedLabel.BackColor = Color.Green;
                sun_hours[selected_hour - 1] = 0;
            }
            activity_label.Text = "";
            color_days();
        }

        private void PictureBox8_Click(object sender, EventArgs e)
        {
            panel1.Visible = false;
            panel2.Visible = false;
            panel3.Visible = false;
        }

        private void Facebook_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("http://www.facebook.com.tr");
        }

        private void Twitter_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("http://www.twitter.com");
        }

        private void Linkedin_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("http://www.linkedin.com.tr");
        }

        private void Share_activity_Click(object sender, EventArgs e)
        {
            label19.Visible = true;
            mailSubject.Visible = true;
            panel3.Visible = true;
            richTextBox1.Visible = false;
            add.Visible = false;

            
            label_content.Visible = true;
            content_textbox.Visible = true;
            send_mail.Visible = true;

            if (username == "" || password == "")
            {
                send_mail.Enabled = false;
            }

        }

        private void Send_mail_Click(object sender, EventArgs e)
        {
            panel7.Visible = true;
        }

        private void SourceLabel_Click(object sender, EventArgs e)
        {

        }

        private void Show_details_Click(object sender, EventArgs e)
        {
            news_details.Visible = true;

        }

        private void youtube_click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("http://www.youtube.com.tr");
        }

        private void email_submit_Click(object sender, EventArgs e)
        {
            send_mail.Enabled = true;
            user = textBox3.Text;
            username = textBox2.Text;
            password = textBox1.Text;     

            if (textBox3.Text.Trim() == string.Empty || textBox2.Text.Trim() == string.Empty || textBox1.Text.Trim() == string.Empty)
            {
                MessageBox.Show(this, "This field cannot be empty!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            textBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";
        }



        private void Enter_Click(object sender, EventArgs e)
        {
           
            this.BackColor = Color.FromName(backcolor);
            panel1.BackColor = Color.FromName(backcolor);
            panel2.BackColor = Color.FromName(backcolor);
            panel3.BackColor = Color.FromName(backcolor);
            panel4.BackColor = Color.FromName(backcolor);
            panel5.BackColor = Color.FromName(backcolor);


        }

        private void Chart1_Click(object sender, EventArgs e)
        {

        }

   


        private void Social5_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("http://www.instagram.com");
        }


        private void PictureBox14_Click(object sender, EventArgs e)
        {
            panel5.Visible = true;
        }

        private void PictureBox23_Click(object sender, EventArgs e)
        {
            panel5.Visible = false;
        }


        private void Timer1_Tick(object sender, EventArgs e)
        {
            clock.Text = DateTime.Now.ToString();
        }

        private void Button4_Click(object sender, EventArgs e)
        {
            for (int selected_hour = 1; selected_hour <= 24; selected_hour++)
            {
                mon_activity[selected_hour - 1] = "";
                tue_activity[selected_hour - 1] = "";
                wed_activity[selected_hour - 1] = "";
                thu_activity[selected_hour - 1] = "";
                fri_activity[selected_hour - 1] = "";
                sat_activity[selected_hour - 1] = "";
                sun_activity[selected_hour - 1] = "";
                mon_hours[selected_hour - 1] = 0;
                tue_hours[selected_hour - 1] = 0;
                wed_hours[selected_hour - 1] = 0;
                thu_hours[selected_hour - 1] = 0;
                fri_hours[selected_hour - 1] = 0;
                sat_hours[selected_hour - 1] = 0;
                sun_hours[selected_hour - 1] = 0;
                clickedLabel.BackColor = Color.Green;
                activity_label.Text = "";

            }
            for (int i = 1; i < 25; i++)
            {
                Control match = this.Controls.Find("am_" + (i).ToString(), true).FirstOrDefault();
                match.BackColor = Color.Green;
            }
            color_days();
        }

        private void Label13_Click(object sender, EventArgs e)
        {

        }

        private void Label16_Click(object sender, EventArgs e)
        {

        }

        private void Button3_Click(object sender, EventArgs e)
        {

        }

        private void Remove_mail_Click(object sender, EventArgs e)
        {

        }

        private void Add_button_Click(object sender, EventArgs e)
        {


            if (name_text.Text.Trim() == string.Empty|| surname_text.Text.Trim() == string.Empty|| email_text.Text.Trim() == string.Empty|| number_text.Text.Trim() == string.Empty)
            {
                MessageBox.Show(this, "This field cannot be empty!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

                combo_contacts.Items.Clear();
            if (!user_mail.Contains(email_text.Text.ToString()))
            {
                user_name.Add(name_text.Text.ToString());
                user_surname.Add(surname_text.Text.ToString());
                user_mail.Add(email_text.Text.ToString());
                user_number.Add(number_text.Text.ToString());
            }
            else
            {
                MessageBox.Show(this, "This user already exists!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            for (int i = 0; i < user_name.Count; i++)
                combo_contacts.Items.Add(i.ToString() + " " + user_name[i] +" " +user_surname[i]+ " " + "+" +user_number[i] + " "+ user_mail[i] );

            StringBuilder sbOutput = new StringBuilder();        
            for (int i = 0; i < user_name.Count; i++)    
                sbOutput.AppendLine(string.Join(strSeperator,(user_name[i].ToString() + ","+ user_surname[i].ToString() + "," +  user_mail[i].ToString() +"," + user_number[i].ToString())));
            File.WriteAllText(strFilePath, sbOutput.ToString());

            name_text.Text="";
            surname_text.Text = "";
            email_text.Text = "";
            number_text.Text = "";




        }



        private void Remove_button_Click(object sender, EventArgs e)
        {
            combo_contacts.Items.Clear();
            string mail = remove_email.Text.ToString();
            if (user_mail.Contains(mail))
            {
                int mail_to_delete = user_mail.IndexOf(mail);
                user_mail.Remove(mail);
                user_name.RemoveAt(mail_to_delete);
                user_number.RemoveAt(mail_to_delete);
                for (int i = 0; i < user_name.Count; i++)
                    combo_contacts.Items.Add(i.ToString() + " " + user_name[i] + " " + user_surname[i] + " " + "+" + user_number[i] + " " + user_mail[i]);

            }
            else
            {
                MessageBox.Show(this, "This user doesn't exists!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            StringBuilder sbOutput = new StringBuilder();
            for (int i = 0; i < user_name.Count; i++)
                sbOutput.AppendLine(string.Join(strSeperator, (user_name[i].ToString() + "," + user_surname[i].ToString() + "," + user_mail[i].ToString()+  ","+ user_number[i].ToString())));
            File.WriteAllText(strFilePath, sbOutput.ToString());
            remove_email.Text = "";
        }

        private void Send_Click(object sender, EventArgs e)
        {

            

            string[] WeekDays = { "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday" };


            try
            {
                SmtpClient sc = new SmtpClient();
                sc.Port = 587;
                sc.Host = "smtp.gmail.com";
                sc.EnableSsl = true;
                sc.Credentials = new NetworkCredential(username, password);
                MailMessage mail = new MailMessage();
                mail.From = new System.Net.Mail.MailAddress(username, password);
                mail.Subject = mailSubject.Text.ToString();
                mail.IsBodyHtml = true;
               
                
                string content = "Dear Sir/Madam, the details of the "+ mailSubject.Text.ToString() + " are provided below. Please respond as 'Yes' if you want to attend the event. " +
                    "Activity Day: This " + WeekDays[day - 1] + "    " + "Hour: " + selected_hour.ToString() + ":00    ";
                content += "\n" + content_textbox.Text.ToString();
                mail.Body = content;
                for (int i = 0; i < user_name.Count; i++)
                {
                    mail.To.Add(user_mail[i]);
                    sc.Send(mail);
                }
                MessageBox.Show(this, "Your mail is sent!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, ex.ToString(), "Sending Failed", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }


            const string accountSid = "ACe125a7b11ae0c0b561a19df5915429da";
            const string authToken = "8d74b2e94a4c160ffa777e7349b1d8b9";
            TwilioClient.Init(accountSid, authToken);

            for (int i = 0; i < user_mail.Count; i++)
            {
                user_number[i] = "+" + user_number[i];
                var message = MessageResource.Create(
                    body: "Dear Sir / Madam, the details of the " + mailSubject.Text.ToString() + " are provided below.Please respond as 'Yes' if you want to attend the event. " +
                    "Activity Day: This " + WeekDays[day - 1] + "    " + "Hour: " + selected_hour.ToString() + ":00    " + content_textbox.Text.ToString(),
                    from: new Twilio.Types.PhoneNumber("whatsapp:+14155238886"),
                    //to: new Twilio.Types.PhoneNumber("+"+user_number[i])
                    
                    to: new Twilio.Types.PhoneNumber("whatsapp:"+user_number[i])
                ); 
            }

        }

        private void Retrieve_Click(object sender, EventArgs e)
        {   
            string check_text = SubjectName.Text.ToString();
            try
            {
                combo_joining_contacts.Items.Clear();
                MailServer oServer = new MailServer("imap.gmail.com", username, password, ServerProtocol.Imap4);
                oServer.SSLConnection = true;
                oServer.Port = 993;
                MailClient oClient = new MailClient("TryIt");
                oClient.Connect(oServer);
                MailInfo[] infos = oClient.GetMailInfos();
                StringBuilder sbOutput = new StringBuilder();
                for (int i = 0; i < infos.Length; i++)
                {
                    MailInfo info = infos[i];
                    Mail oMail = oClient.GetMail(info);
                    if (oMail.Subject.ToString().Contains(check_text))
                    {
                        if (oMail.TextBody.ToString().Contains("Yes"))
                        {
                            for (int k = 0; k < user_mail.Count; k++)
                            {
                                if (oMail.From.ToString().Contains(user_mail[k].ToString()))
                                {
                                    if (!user_context_joining.Contains(check_text) && !user_mail_joining.Contains(user_name[k]))
                                    {
                                        user_name_joining.Add(user_name[k]);
                                        user_surname_joining.Add(user_surname[k]);
                                        user_mail_joining.Add(user_mail[k]);
                                        user_number_joining.Add(user_number[k]);
                                        user_context_joining.Add(check_text);
                                       
                                    }
                                }
                            }
                        }
                    }

                }
                for (int j = 0; j < user_name_joining.Count; j++)
                {
                    if (user_context_joining[j].Contains(check_text)) { 
                        combo_joining_contacts.Items.Add(user_name_joining[j] + " " + user_surname_joining[j] + " " + "+" + user_number_joining[j]
                            + " " + user_mail_joining[j] + " "+ check_text);
                    }
                    sbOutput.AppendLine(string.Join(strSeperator, (user_name_joining[j].ToString() + "," + user_surname_joining[j].ToString() + "," + user_mail_joining[j].ToString() + "," + user_context_joining[j].ToString() + ","+user_number_joining[j].ToString())));
                    File.WriteAllText(strFilePath2, sbOutput.ToString());
                }

                oClient.Quit();
            }
            catch (Exception ep)
            {
                MessageBox.Show(this, ep.ToString(), "Sending Failed", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void Coeditor_Click(object sender, EventArgs e)
        {
            //-----------------------------SENDING REQUEST MAIL TO THE PROSPECTIVE CO-EDITOR
            try
            {
                SmtpClient sc = new SmtpClient();
                sc.Port = 587;
                sc.Host = "smtp.gmail.com";
                sc.EnableSsl = true;
                sc.Credentials = new NetworkCredential(username, password);
                MailMessage mail = new MailMessage();
                mail.From = new System.Net.Mail.MailAddress(username, password);
                mail.Subject = "CO-EDITOR";
                mail.IsBodyHtml = true;
                mail.To.Add(coeditor_mail.Text.ToString());
                mail.Body = "Hello Sir/Madam, I am planning to assign you as the co-editor to all of the activities I am conducting this week.\n" +
                    "If you approve this please send me a mail (the response YES) asap \n" + "Have a nice week.";
                sc.Send(mail);
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, ex.ToString(), "Sending Failed", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            System.Threading.Thread.Sleep(30000); // to wait for the response mail

            //-------------------------CHECKING THE RESPONSE OF THE CO-EDITOR


            try
            {
                MailServer oServer = new MailServer("imap.gmail.com", username, password, ServerProtocol.Imap4);
                oServer.SSLConnection = true;
                oServer.Port = 993;
                MailClient oClient = new MailClient("TryIt");
                oClient.Connect(oServer);
                MailInfo[] infos = oClient.GetMailInfos();
                for (int i = 0; i < infos.Length; i++)
                {
                    MailInfo info = infos[i];
                    Mail oMail = oClient.GetMail(info);
                    if (oMail.Subject.ToString().Contains("CO-EDITOR"))
                    {
                        if (oMail.TextBody.ToString().Contains("Yes"))
                        {
                            if (oMail.From.ToString().Contains(coeditor_mail.Text.ToString()))
                            {
                                try
                                {
                                    MailMessage mail = new MailMessage();
                                    SmtpClient SmtpServer = new SmtpClient("smtp.gmail.com");
                                    mail.From = new System.Net.Mail.MailAddress(username);
                                    mail.To.Add(coeditor_mail.Text.ToString());
                                    mail.Subject = "Contact Details";
                                    mail.Body = "Dear Sir/Madam, Thank you for accepting the Co-editor position. \n You can find the attachments in the files below";
                                    System.Net.Mail.Attachment attachment;
                                    attachment = new System.Net.Mail.Attachment(strFilePath);
                                    attachment.Name = "contacts.csv";
                                    mail.Attachments.Add(attachment);
                                    attachment = new System.Net.Mail.Attachment(strFilePath2);
                                    attachment.Name = "joining_contacts.csv";
                                    mail.Attachments.Add(attachment);
                                    SmtpServer.Port = 587;
                                    SmtpServer.Credentials = new System.Net.NetworkCredential(username, password);
                                    SmtpServer.EnableSsl = true;
                                    SmtpServer.Send(mail);
                                    MessageBox.Show(this, "The individual accepted the Co-editorship position!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                }
                                catch (Exception ep)
                                {
                                    MessageBox.Show(this, ep.ToString(), "Sending Failed", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                }

                            }
                        }
                    }

                }

                oClient.Quit();
            }
            catch (Exception ep)
            {
                MessageBox.Show(this, ep.ToString(), "Sending Failed", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }
    }
}
